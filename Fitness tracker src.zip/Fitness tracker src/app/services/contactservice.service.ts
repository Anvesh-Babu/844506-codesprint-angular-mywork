import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ContactDetails } from '../models/contact-details';

export const API_URL="http://localhost:3000/contact-details";
@Injectable({
  providedIn: 'root'
})
export class ContactserviceService {
  
  constructor(public http:HttpClient) { }
  
  addContactDetails(details:ContactDetails){
    return this.http.post(API_URL,details);
  }
  getContactDetails():any{
    return this.http.get("API_URL");
    }
 
}
