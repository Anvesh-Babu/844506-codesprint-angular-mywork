import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { ContactDetails } from '../models/contact-details';
import { ContactserviceService } from '../services/contactservice.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  name : string;
  email : string;
  message:string;
  trainer:string;
  errtext : string='';
  sucesstxt:string;
  myFormGroup : FormGroup;
 
  constructor(formBuilder: FormBuilder, public route : Router , public details : ContactserviceService) {
    this.myFormGroup=formBuilder.group({
      "name":new FormControl(""),
      "email":new FormControl(""),
      "message":new FormControl(""),
      "trainer":new FormControl("")
    })
   }
  reg(){
    this.name=this.myFormGroup.controls['name'].value;
    this.email = this.myFormGroup.controls['email'].value;
    this.message=this.myFormGroup.controls['message'].value;
    this.trainer=this.myFormGroup.controls['trainer'].value;
    if(this.name!=null||this.email!=null){
        let details =new ContactDetails(this.name,this.email,this.message,this.trainer);
       this.details.addContactDetails(details).subscribe((response)=> console.log(response));
    console.log("Name:" + this.name+"\n"+"Email:"+this.email+"\n"+"Message:"+this.message+"\n"+"Trainer:"+this.trainer);
      }
      else{
        alert("Please fill Name and Email!!");
      }
  }

  ngOnInit(): void {
  }

}
